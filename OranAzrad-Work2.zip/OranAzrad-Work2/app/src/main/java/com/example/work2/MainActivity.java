package com.example.work2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.work2.fragments.AddStudentFragment;
import com.example.work2.fragments.AddTeacherFragment;
import com.example.work2.fragments.AssignStudentToCourseFragment;
import com.example.work2.fragments.AssignTeacherToCourseFragment;
import com.example.work2.fragments.CreateCourseFragment;
import com.example.work2.fragments.ViewStudentsByCourseFragment;

public class MainActivity extends AppCompatActivity {

    Button btnAddStudent;
    Button btnCreateCourse;
    Button btnShowCourseStudent;
    Button btnAddTeacher;
    Button btnConnectTeacherCourse;
    Button btnCourseOfStudent;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //conect all the btns
        btnAddStudent = findViewById(R.id.btnAddStudent);
        btnCreateCourse = findViewById(R.id.btnCreateCourse);
        btnShowCourseStudent = findViewById(R.id.btnShowCourseStudent);
        btnAddTeacher = findViewById(R.id.btnAddTeacher);
        btnConnectTeacherCourse = findViewById(R.id.btnConnectTeacherCourse);
        btnCourseOfStudent = findViewById(R.id.btnCourseOfStudent);

        loadFragment(new AddStudentFragment());

        //add the options to the btns
        btnAddStudent.setOnClickListener(v -> loadFragment(new AddStudentFragment()));
        btnCreateCourse.setOnClickListener(v -> loadFragment(new CreateCourseFragment()));
        btnShowCourseStudent.setOnClickListener(v -> loadFragment(new ViewStudentsByCourseFragment()));
        btnAddTeacher.setOnClickListener(v -> loadFragment(new AddTeacherFragment()));
        btnConnectTeacherCourse.setOnClickListener(v -> loadFragment(new AssignTeacherToCourseFragment()));
        btnCourseOfStudent.setOnClickListener(v -> loadFragment(new AssignStudentToCourseFragment()));
    }

    // Utility function to load fragments
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
